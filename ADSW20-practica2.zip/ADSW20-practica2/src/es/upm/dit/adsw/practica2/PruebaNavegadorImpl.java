/**
 * @author Nerea Encarnación Gonzalez-Cutre
 * @author Javier García Céspedes
 *
 */
package es.upm.dit.adsw.practica2;

import static org.junit.Assert.*;

import org.junit.Test;

public class PruebaNavegadorImpl {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
